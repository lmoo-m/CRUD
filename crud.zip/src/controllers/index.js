const jurusan = require("./controllerJurusan");

module.exports = {
    jurusan,
};
