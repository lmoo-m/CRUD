module.exports = {
    multipleStatements: true,
    host: "localhost",
    user: "sita_dbcampus",
    password: "testing",
    database: "sita_dbcampus",
};
